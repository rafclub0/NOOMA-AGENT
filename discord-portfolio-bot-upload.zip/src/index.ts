import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  Client,
  ChatInputCommandInteraction,
  EmbedBuilder,
  GatewayIntentBits,
  Interaction,
  ModalBuilder,
  PermissionFlagsBits,
  REST,
  Routes,
  SelectMenuComponentOptionData,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  TextChannel,
  User,
  VoiceChannel,
  SlashCommandBuilder,
} from "discord.js";
import {
  addPoints,
  addProject,
  archivePreviousMonths,
  getOrCreatePortfolio,
  getProfile,
  getProject,
  getProjects,
  projectStats,
  recordVote,
  topGraphists,
  type Project,
} from "./db.js";

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;
const guildId = process.env.DISCORD_GUILD_ID;
if (!token || !clientId || !guildId) {
  throw new Error("DISCORD_TOKEN, DISCORD_CLIENT_ID et DISCORD_GUILD_ID sont requis.");
}

const categories = ["Thumbnail", "Logo", "Banner", "Overlay", "Autre"] as const;
const commands = [
  new SlashCommandBuilder()
    .setName("portfolio")
    .setDescription("Gérer un portfolio de graphiste")
    .addSubcommand((sub) => sub.setName("creer").setDescription("Créer ou afficher ton portfolio"))
    .addSubcommand((sub) =>
      sub.setName("ajouter").setDescription("Ajouter une création")
        .addStringOption((option) => option.setName("titre").setDescription("Titre de la création").setRequired(true).setMaxLength(80))
        .addStringOption((option) => option.setName("categorie").setDescription("Catégorie").setRequired(true)
          .addChoices(...categories.map((category) => ({ name: category, value: category }))))
        .addAttachmentOption((option) => option.setName("fichier").setDescription("Image de la création"))
        .addStringOption((option) => option.setName("url").setDescription("Ou URL publique de l'image")),
    )
    .addSubcommand((sub) =>
      sub.setName("voir").setDescription("Voir le portfolio d'un membre")
        .addUserOption((option) => option.setName("utilisateur").setDescription("Membre à consulter")),
    ),
  new SlashCommandBuilder().setName("top-graphistes").setDescription("Voir le Top 10 mensuel des graphistes"),
  new SlashCommandBuilder().setName("help").setDescription("Voir l'aide du bot et toutes ses fonctionnalités"),
  new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Configurer les salons du serveur")
    .addSubcommand((sub) => sub.setName("server").setDescription("Créer la structure Portfolio Graphistes")),
].map((command) => command.toJSON());

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

function log(message: string, error?: unknown): void {
  if (error) console.error(`[portfolio-bot] ${message}`, error);
  else console.error(`[portfolio-bot] ${message}`);
}

function profileEmbed(user: User, projectCount: number): EmbedBuilder {
  const profile = getProfile(user.id);
  return new EmbedBuilder()
    .setColor(0x7c3aed)
    .setAuthor({ name: `Portfolio de ${user.displayName}`, iconURL: user.displayAvatarURL() })
    .setDescription(profile ? `**${profile.badge}**\n\nUn espace pour présenter ses créations à la communauté.` : "Profil prêt à accueillir tes créations.")
    .addFields(
      { name: "Score global", value: `${profile?.global_points ?? 0} points`, inline: true },
      { name: "Créations", value: `${projectCount}`, inline: true },
      { name: "Likes & notes", value: "Utilise les boutons sous chaque création", inline: false },
    )
    .setFooter({ text: "Portfolio Graphistes • classement mensuel" });
}

function voteButtons(projectId: number): ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder> {
  return new ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`like:${projectId}`).setLabel("J'aime  +10").setEmoji("💖").setStyle(ButtonStyle.Primary),
    new StringSelectMenuBuilder().setCustomId(`rate:${projectId}`).setPlaceholder("Noter la création")
      .addOptions([1, 2, 3, 4, 5].map((rating): SelectMenuComponentOptionData => ({
        label: `${rating} étoile${rating > 1 ? "s" : ""}`,
        value: String(rating),
        emoji: "⭐",
      }))),
  );
}

function projectEmbed(project: Project, position: number, total: number): EmbedBuilder {
  const stats = projectStats(project.id);
  return new EmbedBuilder()
    .setColor(0x00d9ff)
    .setTitle(project.title)
    .setDescription(`**${project.category}**  •  Création ${position + 1}/${total}\n\n💖 ${stats.likes} likes   ⭐ ${Number(stats.average_rating).toFixed(1)}/5   ✦ ${stats.points} points`)
    .setImage(project.imageUrl)
    .setFooter({ text: "Une réaction par membre et par création" });
}

function navigationRow(userId: string, position: number, total: number): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`previous:${userId}:${position}`).setLabel("Précédent").setStyle(ButtonStyle.Secondary).setDisabled(position <= 0),
    new ButtonBuilder().setCustomId(`next:${userId}:${position}`).setLabel("Suivant").setStyle(ButtonStyle.Secondary).setDisabled(position >= total - 1),
  );
}

async function syncRole(userId: string, globalPoints: number): Promise<void> {
  const guild = client.guilds.cache.get(guildId!);
  const member = await guild?.members.fetch(userId).catch(() => null);
  if (!guild || !member) return;
  const roleName = globalPoints >= 1000 ? "Graphiste Légende" : globalPoints >= 500 ? "Graphiste Élite" : globalPoints >= 100 ? "Graphiste Confirmé" : null;
  for (const name of ["Graphiste Confirmé", "Graphiste Élite", "Graphiste Légende"]) {
    const role = guild.roles.cache.find((candidate) => candidate.name === name);
    if (role && roleName !== name && member.roles.cache.has(role.id)) await member.roles.remove(role).catch(() => undefined);
  }
  if (roleName) {
    let role = guild.roles.cache.find((candidate) => candidate.name === roleName);
    if (!role && guild.members.me?.permissions.has(PermissionFlagsBits.ManageRoles)) role = await guild.roles.create({ name: roleName, color: 0x7c3aed, reason: "Progression Portfolio Graphistes" });
    if (role && !member.roles.cache.has(role.id)) await member.roles.add(role).catch(() => undefined);
  }
  if (globalPoints >= 1000) {
    const base = `atelier-${member.user.username}`.slice(0, 90);
    const existing = guild.channels.cache.find((channel) => channel.name === base);
    if (!existing && guild.members.me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      await guild.channels.create({ name: base, type: 0, permissionOverwrites: [{ id: guild.roles.everyone.id, deny: ["ViewChannel"] }, { id: userId, allow: ["ViewChannel", "SendMessages"] }] });
      await guild.channels.create({ name: `${base}-vocal`, type: 2, permissionOverwrites: [{ id: guild.roles.everyone.id, deny: ["ViewChannel"] }, { id: userId, allow: ["ViewChannel", "Connect", "Speak"] }] });
    }
  }
}

async function respondWithPortfolio(interaction: ChatInputCommandInteraction, user: User): Promise<void> {
  const projects = getProjects(user.id);
  const embed = profileEmbed(user, projects.length);
  if (!projects.length) {
    embed.setDescription(`${embed.data.description ?? ""}\n\nAucune création pour le moment. Utilise \`/portfolio ajouter\` pour commencer.`);
    await interaction.reply({ embeds: [embed], ephemeral: false });
    return;
  }
  await interaction.reply({
    embeds: [embed, projectEmbed(projects[0], 0, projects.length)],
    components: [voteButtons(projects[0].id), navigationRow(user.id, 0, projects.length)],
  });
}

async function setupServer(interaction: ChatInputCommandInteraction): Promise<void> {
  if (!interaction.guild) {
    await interaction.reply({ content: "Cette commande doit être utilisée dans un serveur.", ephemeral: true });
    return;
  }
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    await interaction.reply({ content: "Tu dois avoir la permission **Gérer le serveur** pour utiliser cette commande.", ephemeral: true });
    return;
  }
  if (!interaction.guild.members.me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
    await interaction.reply({ content: "Je dois avoir la permission **Gérer les salons** pour préparer le serveur.", ephemeral: true });
    return;
  }

  await interaction.deferReply({ ephemeral: true });
  const guild = interaction.guild;
  const categoryDefinitions = [
    {
      name: "👋・ACCUEIL",
      channels: [
        { name: "📜・bienvenue", topic: "Bienvenue dans la communauté des graphistes." },
        { name: "📢・annonces", topic: "Annonces et informations importantes de la communauté." },
        { name: "📌・reglement", topic: "Règlement et bonnes pratiques du serveur." },
        { name: "🤝・presentations", topic: "Présente-toi à la communauté." },
      ],
    },
    {
      name: "🎨・GRAPHISME",
      channels: [
        { name: "🖼️・presente-ta-creation", topic: "Partage tes créations via /portfolio ajouter." },
        { name: "🔍・critiques", topic: "Demande et donne des retours constructifs." },
        { name: "💡・idees", topic: "Échange d'idées et d'inspiration." },
        { name: "🧠・conseils", topic: "Conseils pour progresser en graphisme." },
        { name: "🛠️・ressources", topic: "Ressources utiles pour les graphistes." },
        { name: "🧰・logiciels", topic: "Astuces sur les logiciels de création." },
        { name: "📚・tutoriels", topic: "Tutoriels et guides partagés par la communauté." },
        { name: "💖・coups-de-coeur", topic: "Les créations préférées de la communauté." },
      ],
    },
    {
      name: "🌐・COMMUNAUTÉ",
      channels: [
        { name: "💬・general", topic: "Discussions générales de la communauté." },
        { name: "🎮・gaming", topic: "Discussions gaming et Fortnite." },
        { name: "🏅・concours", topic: "Concours et défis créatifs." },
        { name: "📅・evenements", topic: "Événements et activités du serveur." },
        { name: "🎁・entraide", topic: "Demandes d'aide et entraide entre membres." },
      ],
    },
    {
      name: "🧰・OUTILS",
      channels: [
        { name: "🏆・classement", topic: "Résultats du classement mensuel avec /top-graphistes." },
        { name: "🤖・commandes", topic: "Utilise les commandes du bot ici." },
        { name: "🔊・vocal-general", topic: "Salon vocal général." },
      ],
    },
  ] as const;
  const categories = new Map<string, NonNullable<ReturnType<typeof guild.channels.cache.find>>>();
  for (const categoryDefinition of categoryDefinitions) {
    const existing = guild.channels.cache.find((channel) => channel.type === 4 && channel.name === categoryDefinition.name);
    const category = existing ?? await guild.channels.create({ name: categoryDefinition.name, type: 4, reason: "Configuration Portfolio Graphistes" });
    categories.set(categoryDefinition.name, category);
  }
  const channels: Array<{ name: string; topic: string }> = [];
  for (const categoryDefinition of categoryDefinitions) {
    for (const channelDefinition of categoryDefinition.channels) channels.push(channelDefinition);
  }
  const created: string[] = [];
  const moved: string[] = [];
  for (const categoryDefinition of categoryDefinitions) {
    const parent = categories.get(categoryDefinition.name);
    if (!parent) continue;
    for (const channelDefinition of categoryDefinition.channels) {
      const existing = guild.channels.cache.find((channel) => channel.type === 0 && channel.name === channelDefinition.name) as TextChannel | undefined;
      if (existing) {
        if (existing.parentId !== parent.id) {
          await existing.setParent(parent.id, { lockPermissions: false, reason: "Organisation des catégories Portfolio Graphistes" });
          moved.push(channelDefinition.name);
        }
        continue;
      }
    await guild.channels.create({
      name: channelDefinition.name,
      type: 0,
      parent: parent.id,
      topic: channelDefinition.topic,
      reason: "Configuration Portfolio Graphistes",
    });
    created.push(channelDefinition.name);
    }
  }

  let moderatorRole = guild.roles.cache.find((role) => role.name === "🛡️ Modérateur");
  if (!moderatorRole && guild.members.me?.permissions.has(PermissionFlagsBits.ManageRoles)) {
    moderatorRole = await guild.roles.create({
      name: "🛡️ Modérateur",
      color: 0xef4444,
      reason: "Rôle de modération Portfolio Graphistes",
    });
  }
  const moderatorCategoryName = "🛡️・MODÉRATION";
  const moderatorCategory = guild.channels.cache.find((channel) => channel.type === 4 && channel.name === moderatorCategoryName)
    ?? await guild.channels.create({
      name: moderatorCategoryName,
      type: 4,
      reason: "Configuration salons de modération",
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        ...(moderatorRole ? [{ id: moderatorRole.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }] : []),
      ],
    });
  const moderatorChannels = [
    { name: "🔒・mod-chat", topic: "Discussion privée de l'équipe de modération." },
    { name: "📋・logs", topic: "Suivi des événements et actions de modération." },
    { name: "🚨・signalements", topic: "Signalements envoyés par les membres." },
    { name: "📝・sanctions", topic: "Historique et suivi des sanctions." },
    { name: "🗓️・reunions", topic: "Organisation des réunions de l'équipe." },
  ];
  for (const channelDefinition of moderatorChannels) {
    const existing = guild.channels.cache.find((channel) => channel.parentId === moderatorCategory.id && channel.name === channelDefinition.name);
    if (existing) continue;
    await guild.channels.create({
      name: channelDefinition.name,
      type: 0,
      parent: moderatorCategory.id,
      topic: channelDefinition.topic,
      permissionOverwrites: [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        ...(moderatorRole ? [{ id: moderatorRole.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }] : []),
      ],
      reason: "Configuration salons de modération",
    });
    created.push(channelDefinition.name);
  }

  const summary = created.length
    ? `Configuration terminée. **${created.length}** salon${created.length > 1 ? "s" : ""} créé${created.length > 1 ? "s" : ""}${moved.length ? ` et **${moved.length}** déplacé${moved.length > 1 ? "s" : ""}` : ""}.\n\n**Publics :** ${channels.length} salons dans 4 catégories\n**Modération :** ${moderatorChannels.length} salons privés\n\n${created.map((name) => `• ${name}`).join("\n")}`
    : moved.length
      ? `Organisation terminée : **${moved.length}** salon${moved.length > 1 ? "s" : ""} déplacé${moved.length > 1 ? "s" : ""} dans les nouvelles catégories.`
      : `La structure du serveur est déjà complète : **${channels.length} salons publics dans 4 catégories** et **${moderatorChannels.length} salons privés de modération**.`;
  await interaction.editReply({ content: summary });
}

client.once("clientReady", async (readyClient) => {
  archivePreviousMonths();
  const rest = new REST({ version: "10" }).setToken(token!);
  let syncedGuilds = 0;
  for (const guild of readyClient.guilds.cache.values()) {
    try {
      await rest.put(Routes.applicationGuildCommands(clientId!, guild.id), { body: commands });
      syncedGuilds += 1;
    } catch (error) {
      log(`Impossible de synchroniser les commandes dans ${guild.name}.`, error);
    }
  }
  if (syncedGuilds === 0) await rest.put(Routes.applicationCommands(clientId!), { body: commands });
  log(`Connecté en tant que ${readyClient.user.tag}. Commandes synchronisées dans ${syncedGuilds} serveur${syncedGuilds > 1 ? "s" : ""}.`);
});

client.on("error", (error) => log("Erreur Discord", error));

client.on("guildCreate", async (guild) => {
  const rest = new REST({ version: "10" }).setToken(token!);
  try {
    await rest.put(Routes.applicationGuildCommands(clientId!, guild.id), { body: commands });
    log(`Nouveau serveur détecté : commandes synchronisées dans ${guild.name}.`);
  } catch (error) {
    log(`Impossible de synchroniser les commandes dans le nouveau serveur ${guild.name}.`, error);
  }
});

client.on("interactionCreate", async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === "setup" && interaction.options.getSubcommand() === "server") {
        await setupServer(interaction);
        return;
      }
      if (interaction.commandName === "help") {
        const helpEmbed = new EmbedBuilder()
          .setColor(0x7c3aed)
          .setTitle("Aide — Portfolio Graphistes")
          .setDescription("Présente tes créations, récolte des retours et progresse dans le classement de la communauté.")
          .addFields(
            {
              name: "Portfolio",
              value: [
                "`/portfolio creer` — créer ou afficher ton portfolio",
                "`/portfolio ajouter` — ajouter une création avec un titre, une catégorie et une image",
                "`/portfolio voir` — consulter le portfolio d'un membre",
              ].join("\n"),
            },
            {
              name: "Votes et points",
              value: [
                "💖 Un like rapporte **10 points** au créateur.",
                "⭐ Une note de 1 à 5 rapporte **2 à 10 points**.",
                "Chaque membre ne peut liker et noter qu'une seule fois chaque création.",
              ].join("\n"),
            },
            {
              name: "Progression",
              value: [
                "🎨 0–99 points — Graphiste Débutant",
                "🔥 100–499 points — Graphiste Confirmé",
                "💎 500–999 points — Graphiste Élite",
                "👑 1000+ points — Graphiste Légende",
              ].join("\n"),
            },
            {
              name: "Classement",
              value: "`/top-graphistes` — afficher le Top 10 du mois en cours.",
            },
          )
          .setFooter({ text: "Les points du classement sont remis à zéro chaque mois, les badges restent acquis." });
        await interaction.reply({ embeds: [helpEmbed] });
        return;
      }
      if (interaction.commandName === "top-graphistes") {
        const rows = topGraphists();
        const description = rows.length
          ? rows.map((row, index) => `**${index + 1}.** ${row.username} — **${row.points} pts**\n${row.badge} · ${row.global_points} pts globaux`).join("\n\n")
          : "Le classement se remplira dès les premiers votes du mois.";
        await interaction.reply({ embeds: [new EmbedBuilder().setColor(0xf59e0b).setTitle("Top 10 Graphistes").setDescription(description).setFooter({ text: "Classement du mois en cours" })] });
      }
      if (interaction.commandName === "portfolio") {
        const subcommand = interaction.options.getSubcommand();
        if (subcommand === "creer") await respondWithPortfolio(interaction, interaction.user);
        if (subcommand === "voir") await respondWithPortfolio(interaction, interaction.options.getUser("utilisateur") ?? interaction.user);
        if (subcommand === "ajouter") {
          const attachment = interaction.options.getAttachment("fichier");
          const url = attachment?.url ?? interaction.options.getString("url");
          if (!url) {
            await interaction.reply({ content: "Ajoute un fichier image ou une URL publique.", ephemeral: true });
            return;
          }
          const project = addProject(interaction.user.id, interaction.user.username, interaction.options.getString("titre", true), interaction.options.getString("categorie", true), url);
          await interaction.reply({ embeds: [new EmbedBuilder().setColor(0x22c55e).setTitle("Création ajoutée").setDescription(`**${project.title}** a rejoint ton portfolio.`).setImage(project.imageUrl)], components: [voteButtons(project.id)] });
        }
      }
      return;
    }
    if (interaction.isButton()) {
      await handleButton(interaction);
      return;
    }
    if (interaction.isStringSelectMenu()) await handleRating(interaction);
  } catch (error) {
    log("Interaction échouée", error);
    const content = "Une erreur est survenue. Réessaie dans quelques instants.";
    if (interaction.isRepliable()) {
      if (interaction.replied || interaction.deferred) await interaction.followUp({ content, ephemeral: true }).catch(() => undefined);
      else await interaction.reply({ content, ephemeral: true }).catch(() => undefined);
    }
  }
});

async function handleButton(interaction: ButtonInteraction): Promise<void> {
  const [action, first, rawPosition] = interaction.customId.split(":");
  if (action === "like") {
    const project = getProject(Number(first));
    if (!project) return void await interaction.reply({ content: "Cette création n'existe plus.", ephemeral: true });
    const points = recordVote(project, interaction.user.id, "like");
    if (!points) return void await interaction.reply({ content: "Tu as déjà aimé cette création.", ephemeral: true });
    const profile = getProfile(project.ownerId);
    await syncRole(project.ownerId, profile?.global_points ?? 0);
    await interaction.reply({ content: `Like enregistré : le graphiste gagne ${points} points.`, ephemeral: true });
    return;
  }
  if (action !== "previous" && action !== "next") return;
  const userId = first;
  const projects = getProjects(userId);
  const current = Number(rawPosition);
  const position = action === "next" ? current + 1 : current - 1;
  const project = projects[position];
  if (!project) return;
  await interaction.update({ embeds: [projectEmbed(project, position, projects.length)], components: [voteButtons(project.id), navigationRow(userId, position, projects.length)] });
}

async function handleRating(interaction: StringSelectMenuInteraction): Promise<void> {
  const [, rawId] = interaction.customId.split(":");
  const project = getProject(Number(rawId));
  if (!project) return void await interaction.reply({ content: "Cette création n'existe plus.", ephemeral: true });
  const rating = Number(interaction.values[0]);
  const points = recordVote(project, interaction.user.id, "rating", rating);
  if (!points) return void await interaction.reply({ content: "Tu as déjà noté cette création.", ephemeral: true });
  const profile = getProfile(project.ownerId);
  await syncRole(project.ownerId, profile?.global_points ?? 0);
  await interaction.reply({ content: `Note enregistrée : ${rating}/5, soit ${points} points pour le graphiste.`, ephemeral: true });
}

setInterval(archivePreviousMonths, 60 * 60 * 1000);
client.login(token).catch((error) => {
  log("Connexion Discord impossible", error);
  process.exitCode = 1;
});
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { DatabaseSync } from "node:sqlite";

export type Project = {
  id: number;
  portfolioId: number;
  ownerId: string;
  title: string;
  category: string;
  imageUrl: string;
  createdAt: string;
};

const dbPath = process.env.SQLITE_PATH ?? "data/portfolio.sqlite";
mkdirSync(dirname(dbPath), { recursive: true });
export const db = new DatabaseSync(dbPath);
db.exec("PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;");

db.exec(`
  CREATE TABLE IF NOT EXISTS profiles (
    user_id TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    global_points INTEGER NOT NULL DEFAULT 0,
    badge TEXT NOT NULL DEFAULT '🎨 Graphiste Débutant',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS portfolios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL UNIQUE REFERENCES profiles(user_id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    portfolio_id INTEGER NOT NULL REFERENCES portfolios(id) ON DELETE CASCADE,
    owner_id TEXT NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    image_url TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS votes (
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    voter_id TEXT NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('like', 'rating')),
    rating INTEGER,
    points INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, voter_id, kind)
  );
  CREATE TABLE IF NOT EXISTS monthly_points (
    month TEXT NOT NULL,
    user_id TEXT NOT NULL,
    points INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (month, user_id)
  );
  CREATE TABLE IF NOT EXISTS score_history (
    month TEXT NOT NULL,
    user_id TEXT NOT NULL,
    points INTEGER NOT NULL,
    archived_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (month, user_id)
  );
`);

export function monthKey(date = new Date()): string {
  return date.toISOString().slice(0, 7);
}

export function ensureProfile(userId: string, username: string): void {
  db.prepare(`
    INSERT INTO profiles (user_id, username) VALUES (?, ?)
    ON CONFLICT(user_id) DO UPDATE SET username = excluded.username, updated_at = CURRENT_TIMESTAMP
  `).run(userId, username);
}

export function badgeFor(points: number): string {
  if (points >= 1000) return "👑 Graphiste Légende";
  if (points >= 500) return "💎 Graphiste Élite";
  if (points >= 100) return "🔥 Graphiste Confirmé";
  return "🎨 Graphiste Débutant";
}

export function addPoints(userId: string, username: string, points: number): void {
  const month = monthKey();
  ensureProfile(userId, username);
  db.exec("BEGIN");
  try {
    const current = db.prepare("SELECT global_points FROM profiles WHERE user_id = ?").get(userId) as { global_points: number };
    db.prepare(`
      UPDATE profiles SET global_points = global_points + ?, badge = ?, updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).run(points, badgeFor(current.global_points + points), userId);
    db.prepare(`
      INSERT INTO monthly_points (month, user_id, points) VALUES (?, ?, ?)
      ON CONFLICT(month, user_id) DO UPDATE SET points = points + excluded.points
    `).run(month, userId, points);
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

export function getOrCreatePortfolio(userId: string, username: string): number {
  ensureProfile(userId, username);
  db.prepare("INSERT OR IGNORE INTO portfolios (user_id) VALUES (?)").run(userId);
  return (db.prepare("SELECT id FROM portfolios WHERE user_id = ?").get(userId) as { id: number }).id;
}

export function getProfile(userId: string) {
  return db.prepare("SELECT * FROM profiles WHERE user_id = ?").get(userId) as
    | { user_id: string; username: string; global_points: number; badge: string }
    | undefined;
}

export function addProject(userId: string, username: string, title: string, category: string, imageUrl: string): Project {
  const portfolioId = getOrCreatePortfolio(userId, username);
  const result = db.prepare(`
    INSERT INTO projects (portfolio_id, owner_id, title, category, image_url)
    VALUES (?, ?, ?, ?, ?)
  `).run(portfolioId, userId, title, category, imageUrl);
  return db.prepare("SELECT * FROM projects WHERE id = ?").get(Number(result.lastInsertRowid)) as Project;
}

export function getProjects(userId: string): Project[] {
  return db.prepare("SELECT * FROM projects WHERE owner_id = ? ORDER BY id DESC").all(userId) as Project[];
}

export function getProject(projectId: number): Project | undefined {
  return db.prepare("SELECT * FROM projects WHERE id = ?").get(projectId) as Project | undefined;
}

export function recordVote(project: Project, voterId: string, kind: "like" | "rating", rating?: number): number {
  const points = kind === "like" ? 10 : Math.max(2, Math.min(10, (rating ?? 1) * 2));
  const result = db.prepare(`
    INSERT OR IGNORE INTO votes (project_id, voter_id, kind, rating, points) VALUES (?, ?, ?, ?, ?)
  `).run(project.id, voterId, kind, rating ?? null, points);
  if (result.changes === 0) return 0;
  addPoints(project.ownerId, getProfile(project.ownerId)?.username ?? "Graphiste", points);
  return points;
}

export function projectStats(projectId: number) {
  return db.prepare(`
    SELECT
      COALESCE(SUM(CASE WHEN kind = 'like' THEN 1 ELSE 0 END), 0) AS likes,
      COALESCE(AVG(CASE WHEN kind = 'rating' THEN rating END), 0) AS average_rating,
      COALESCE(SUM(points), 0) AS points
    FROM votes WHERE project_id = ?
  `).get(projectId) as { likes: number; average_rating: number; points: number };
}

export function topGraphists(limit = 10) {
  return db.prepare(`
    SELECT p.user_id, pr.username, p.points, pr.global_points, pr.badge
    FROM monthly_points p JOIN profiles pr ON pr.user_id = p.user_id
    WHERE p.month = ? ORDER BY p.points DESC, pr.global_points DESC LIMIT ?
  `).all(monthKey(), limit) as Array<{ user_id: string; username: string; points: number; global_points: number; badge: string }>;
}

export function archivePreviousMonths(): void {
  const current = monthKey();
  db.prepare(`
    INSERT OR IGNORE INTO score_history (month, user_id, points)
    SELECT month, user_id, points FROM monthly_points WHERE month < ?
  `).run(current);
  db.prepare("DELETE FROM monthly_points WHERE month < ?").run(current);
}